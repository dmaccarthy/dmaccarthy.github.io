sc8pr 3.0 is a package for Python 3.7+ and pygame 1.9+.
This Gallery demonstrates some of the things you can do with sc8pr.

Click the play button at the top of the Code screen.

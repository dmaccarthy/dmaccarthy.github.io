#!python3

# Copyright 2015-2017 D.G. MacCarthy <http://dmaccarthy.github.io>
#
# This file is part of "sc8pr_gallery".
#
# "sc8pr_gallery" is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# "sc8pr_gallery" is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with "sc8pr_gallery".  If not, see <http://www.gnu.org/licenses/>.


from sc8pr.sketch import Sketch
from sc8pr.image import Image
from sc8pr.video import Video
from os.path import isfile, split

def setup(sk):
    sk.video = Video()
    sk.font = sk.loadFont("mono", 48)
    sk.animate(draw)
    sk.frameRate = 10000

def draw(sk):
    n = sk.frameNumber
    fn = sk.images.format(n)
    if isfile(fn):
        sk.video.capture(Image(fn))
        if n % 50 == 0: print(n)
    else:
        print("Saving {} frames...".format(n-1))
        sk.quit = True

def main():
    pattern = "img{:05d}.png"
    fldr = input("Folder? ")
    file = input("Pattern? [{}] ".format(pattern))
    if len(file) == 0: file = pattern
    sk = Sketch(setup)
    sk.images = fldr + "/" + file
    file = input("Save as? ")
    path = split(file)
    if "." not in path[-1]: file += ".s8v"
    if len(path[0]) == 0: file = fldr + "/" + file
    sk.play(128)
    sk.video.save(file)
    print("Done!")

main()
#!python3

# Copyright 2015-2017 D.G. MacCarthy <http://dmaccarthy.github.io>
#
# This file is part of "sc8pr_gallery".
#
# "sc8pr_gallery" is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# "sc8pr_gallery" is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with "sc8pr_gallery".  If not, see <http://www.gnu.org/licenses/>.


from sc8pr.sketch import Sketch, OPEN, SAVE, USERINPUT
from sc8pr.video import Video, VideoSprite, FF
from sc8pr.util import CENTER, rgba, logError, defaultExtension
from sc8pr.image import Image
from pygame import KEYDOWN, K_LEFT, K_RIGHT, K_UP, K_DOWN
from threading import Thread
from sys import argv, stderr
from os.path import dirname

WAIT = True
RED, WHITE = rgba("red", "white")
fps = 10, 12, 15, 20, 24, 30, 60

class ExportVid(Thread):
    "Save video as a sequence of files; encode as MP4 if 'ffmpeg' is available"

    def __init__(self, vid, movie, clip):
        super().__init__()
        self.vid = vid
        self.movie = defaultExtension(movie, ".mp4")
        self.clip = clip

    def run(self):
        vid = self.vid.clip(*self.clip)
        try:
            print("Starting export thread")
            path = dirname(self.movie) + "/?/img{}.png"
            vid.export(path, start=self.clip[0], file=stderr, ffmpeg=True,
                out=self.movie, overwrite=True)
        except: logError()


class LoadVid(Thread):
    "Load an S8V video"

    def __init__(self, sk, fn):
        super().__init__()
        self.sk = sk
        self.fn = fn

    def run(self):
        self.sk.user_pending = Video(self.fn, wait=WAIT)


def menu():
    print(""" ESC   > Open
 TAB   > Change Frame Rate
 SPC   > Play/Pause
Arrows > Back/Forward/Start/End
  B    > Play Backwards
  G    > Grab Frame
 S/E   > Clip Start/End
  C    > Clip Reset
  X    > Export\n""")

def setup(sk):
    menu()
    sk.user_pending = None
    sk.frameRate = 30
    sk.setBackground(bgColor=WHITE)
    font = sk.loadFont("serif", 48)
    sk.image_load = Image.text("Loading video!\nPlease wait...", font, RED, align=CENTER)
    if len(argv) > 2: LoadVid(sk, argv[2]).start()
    else: runDialog(sk)

def resetClip(sp):
    sp.mark = [0, len(sp.video)-1]
    return sp

def openVid(sk, ev):
    "Create a new thread to load a video"
    sk.sprites.empty()
    LoadVid(sk, ev.value).start()
    sk.animate(draw, {KEYDOWN:keyDown})

def draw(sk):
    sk.drawBackground()
    if len(sk.sprites):
        # video is running
        sp = sk.sprites[0]
        if sp.costumeTime == 1 and sp.currentCostume == len(sp.video) - 1:
            sp.costumeTime = 0
            print("[End]")
        elif sp.costumeTime == -1 and sp.currentCostume == 0:
            sp.costumeTime = 0
            print("[0]")
        sk.sprites.draw()
    elif sk.user_pending:
        # Video is loaded and ready to run
        sk.user_vid = resetClip(VideoSprite(sk, sk.user_pending))
        sk.user_pending = None
        resume(sk)
    else:
        # Waiting for video to load
        sk.blit(sk.image_load, sk.center, CENTER)

def resume(sk):
    "Continue playing the video"
    sk.sprites.empty()
    sp = sk.user_vid
    sk.sprites.append(sp)
    sk.size = sp.size
    sp.config(zoom = 1, posn = sk.center)
    sk.animate(draw, {KEYDOWN:keyDown})

def runDialog(sk, handler=openVid, initFilter="*.s8v", mode=OPEN):
    "Run a file dialog to choose a video or save name"
    sk.sprites.empty()
    sk.size = 768, 432
    sk.fileDialog(mode, initFilter=initFilter, allowCancel=(handler is export))
    sk.animate(sk.simpleDraw, eventMap={USERINPUT:handler})

def printFrame(sp): print("[{}]".format(sp.currentCostume))

def keyDown(sk, ev):
    "Event handler for keyboard commands"
    k = ev.key
    if k == 27: # Escape
        runDialog(sk)
    elif k == 9: # Tab
        sk.frameRate = fps[(1 + fps.index(sk.frameRate)) % len(fps)]
        print("fps =", sk.frameRate)
    elif len(sk.sprites):
        sp = sk.sprites[0]
        f = sp.currentCostume
        n = len(sp.video)
        if k == 32: # Space bar
            t = sp.costumeTime
            sp.costumeTime = 0 if t else 1#n = 1 - sp.costumeTime
        elif k in (K_LEFT, K_RIGHT): # Arrows
            sp.costumeTime = 0
            if k == K_LEFT: f -= 1
            elif k == K_RIGHT: f += 1
            if f < 0: f += n
            elif f >= n: f -= n
            sp.currentCostume = f
        elif k == 120: # X
            runDialog(sk, export, "*.mp4", SAVE)
        elif k == 103: # G
            runDialog(sk, grab, "*.png", SAVE)
        elif k == 98: # B
            sp.costumeTime = -1
        elif k == K_DOWN:
            sp.currentCostume = 0
        elif k == K_UP:
            sp.currentCostume = len(sp.video) - 1
        elif k in (101, 115): # E, S
            mark = sp.mark[:]
            mark[0 if k == 115 else 1] = sp.currentCostume
            if mark[0] < mark[1]:
                sp.mark = mark
            else: print("Cannot have Start > End!")
            print("Clip", sp.mark)
        elif k == 99: # C
            resetClip(sp)
            print("Clip", sp.mark)
        else: print(k)
        printFrame(sp)
 
def export(sk, ev):
    "Save the entire Video as image files and encode with ffmpeg"
    sp = sk.user_vid
    if ev.value:
        ExportVid(sp.video, ev.value, sp.mark).start()
        resume(sk)

def grab(sk, ev):
    "Save a single frame"
    if ev.value:
        sp = sk.user_vid
        n = sp.currentCostume
        sp.video[n].image.saveAs(ev.value)
        resume(sk)


# Main program...
if len(argv) > 1: FF.cmd = argv[1]
Sketch(setup).play(432, "sc8pr Video Player", mode=0)
    
# sc8pr Gallery

[**sc8pr 3.0**](https://dmaccarthy.github.io/sc8pr/) is a package for [Python 3.7+](https://python.org) and [pygame 1.9+](https://pygame.org). This Gallery demonstrates some of the things you can do with **sc8pr**.

Click the Run button and view the Gallery in the Output tab...
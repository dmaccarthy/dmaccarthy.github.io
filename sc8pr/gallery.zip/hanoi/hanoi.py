#!python3

# Copyright 2015-2017 D.G. MacCarthy <http://dmaccarthy.github.io>
#
# This file is part of "sc8pr_gallery".
#
# "sc8pr_gallery" is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# "sc8pr_gallery" is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with "sc8pr_gallery".  If not, see <http://www.gnu.org/licenses/>.


class TowersOfHanoi:
    "Represent the Towers of Hanoi problem as an iterable object"

    _iterObj = None

    def __init__(self, n):
        "Initialize the state of the disks and towers"
        self.disks = n
        self.state = list(range(n, 0, -1)), [], []
        self.count = 0

    def move(self, n, towerFrom, towerTo):
        "Generate a sequence of states moving one disk at a time"
        if n:
            towerTemp = 3 - towerTo - towerFrom
            for s in self.move(n - 1, towerFrom, towerTemp): yield s
            s = self.state
            s[towerTo].append(s[towerFrom].pop())
            self.count += 1
            yield s
            for s in self.move(n - 1, towerTemp, towerTo): yield s

    def __iter__(self):
        "Make the instance iterable as disks are moved from tower 0 to 1"
        yield self.state
        for s in self.move(self.disks, 0, 1): yield s

    def __next__(self):
        "Return the next state in the sequence"
        if self._iterObj is None: self._iterObj = iter(self)
        return next(self._iterObj)

    @property
    def final(self):
        "Check if disks are in final state"
        return len(self.state[1]) == self.disks

    def __repr__(self):
        return "{}({})".format(type(self).__name__, self.disks)

    def __str__(self):
        return "{:5d}: {} {} {}".format(self.count, *self.state)


prompt = "Number of disks? "

if __name__ == "__main__":
    game = TowersOfHanoi(int(input(prompt)))
    for state in game: print(game)

#!python3

# Copyright 2015-2017 D.G. MacCarthy <http://dmaccarthy.github.io>
#
# This file is part of "sc8pr_gallery".
#
# "sc8pr_gallery" is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# "sc8pr_gallery" is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with "sc8pr_gallery".  If not, see <http://www.gnu.org/licenses/>.


from sc8pr.sketch import Sketch, Sprite#, Capture
from sc8pr.io import number, USERINPUT
from sc8pr.image import Image
from sc8pr.util import rgba, getValues
from hanoi import TowersOfHanoi, prompt
import json

def odd(x): return 1 + 2 * round((x - 1) / 2)

def init(sk):
    "Initialize sketch; prompt for number of disks"
    sk.setBackground(bgColor=rgba("white"))
    n = sk.config.get("disks")
    if n: setup(sk, n)
    else:
        sk.prompt(prompt, number, "6", "Towers of Hanoi",
            allowCancel=False).validConfig(low=2, integer=True)
        sk.animate(None, {USERINPUT:setup})

def setup(sk, n):
    "Initialize Towers of Hanoi animation"
    if type(n) is not int: n = n.value
    first, thick, space, w, h, speed = getValues("first_disk",
         "thick", "space", "width", "height", "speed", **sk.config)
    if h is None: h = 2 * space + thick * n
    sk.size = w, h
    img = Image("city.png").scale(sk.size).setAlpha(24)
    sk.setBackground(img, rgba("#202020ff"))
    big = (w - 4 * space) / 3 - first
    colors = rgba("red", "blue", "yellow", "green",
        "purple", "chocolate", "cyan", "grey")
    for disk in range(n):
        w = odd(first + big * disk / (n - 1))
        c = colors[disk % len(colors)]
        Sprite(sk, Image.rect((w, thick), c))
    sk.frameRate = max(30, speed)
    sk.animate(draw)
    sk.game = TowersOfHanoi(n)
#    sk.capture = Capture(interval=1)

def draw(sk):
    "Draw the disks in three towers"
    game = sk.game
    thick, space, speed = getValues("thick", "space", "speed", **sk.config)
    update = round(sk.frameRate / speed)
    if not game.final and sk.frameNumber % update == 0:
        next(game)
        if sk.config.get("console"): print(game)
    for tower in range(3):
        x = sk.centerX + (tower - 1) * sk.width / 3
        y = sk.height - space - thick / 2
        for disk in game.state[tower]:
            sk.sprites[disk - 1].posn = x, y
            y -= thick
    sk.simpleDraw()

def main():
    "Run the animation"
    sk = Sketch(init)
    try:     # Custom configuration
        with open("hanoi_anim.json", "r") as f: sk.config = json.load(f)
    except:  # Default configuration
        sk.config = {"speed":1, "width":640, "first_disk":24, "thick":12, "space":24}
    sk.play(caption="Towers of Hanoi", mode=0)

main()
